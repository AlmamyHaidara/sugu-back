-- AlterTable
ALTER TABLE "Commande" ALTER COLUMN "updatedAt" DROP NOT NULL;

-- AlterTable
ALTER TABLE "Country" ALTER COLUMN "updatedAt" DROP NOT NULL;
